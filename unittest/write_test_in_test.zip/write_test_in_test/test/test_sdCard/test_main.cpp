#include <unity.h>
#include <iostream>
using namespace std;
#include "SD.h"


#define SCK 18
#define MISO 23
#define MOSI 14
#define CS 19


#include "FS.h"
#include "SPI.h"
#include "SPIFFS.h"
#include "main_app.h"

SPIClass spi = SPIClass(VSPI);

std::vector<String> vecOfstr{"hello"};

typedef enum FS_WRITE{
    OPEN_FILE_FAILED   = 0,
    WRITE_FILE_DONE    = 1,
    WRITE_FILE_FAILED  = 2,
    INIT_FAILED        = 3
}FS_WRITE_STATUS;

typedef enum FS_READ{
    FAILED_FILE_PATH  = 0,
    READ_FILE_DONE    = 1,
    READ_FILE_FAILED = 2,
    FILE_COMPARE = 3,
    FAILED_FILE_COMPARE = 4
}FS_READ_STATUS;

typedef enum FS_DELETE{
    FILE_DELETE_FAILED  = 0,
    FILE_DELETE_SUCCESS = 1
}FS_DELETE_STATUS;



void initSDCard();
// FS_DELETE_STATUS deleteFile(fs::FS &fs, const char *path);
// FS_WRITE_STATUS writeFile(fs::FS &fs, const char *path, const char *message);
// void appendFile(fs::FS &fs, const char *path, String message);
// FS_READ_STATUS send_file_to_k210(fs::FS &fs, const char *path);

void initSDCard()
{
  spi.begin(SCK, MISO, MOSI, CS);

  if (!SD.begin(CS, spi, 80000000))
  {
    Serial.println("Card Mount Failed");
    delay(1000);
    ESP.restart();
    // return;
  }
  uint8_t cardType = SD.cardType();

  if (cardType == CARD_NONE)
  {
    Serial.println("No SD card attached");
    return;
  }

  Serial.print("SD Card Type: ");
  if (cardType == CARD_MMC)
  {
    Serial.println("MMC");
  }
  else if (cardType == CARD_SD)
  {
    Serial.println("SDSC");
  }
  else if (cardType == CARD_SDHC)
  {
    Serial.println("SDHC");
  }
  else
  {
    Serial.println("UNKNOWN");
  }
  uint64_t cardSize = SD.cardSize() / (1024 * 1024);
  Serial.printf("SD Card Size: %lluMB\n", cardSize);
}

int deleteFile(fs::FS &fs, const char *path)
{
  FS_DELETE_STATUS delete_file_status;

  Serial.printf("Deleting file: %s\r\n", path);
  if (fs.remove(path))
  {
    Serial.println("- file deleted");
    delete_file_status = FILE_DELETE_SUCCESS;
  }
  else
  {
    Serial.println("- delete failed");
    delete_file_status = FILE_DELETE_FAILED;
  }
  return delete_file_status;
 }
 
int writeFile(fs::FS &fs, const char *path, const char *message)
{
  
  FS_WRITE_STATUS write_file_status = OPEN_FILE_FAILED; 
  Serial.printf("Writing file: %s\r\n", path);

  File file = fs.open(path, FILE_WRITE);
  if (!file)
  {
    Serial.println("- failed to open file for writing");
    return write_file_status;
  }
  if (file.print(message))
  {
    Serial.println("- file written");
    write_file_status = WRITE_FILE_DONE;
  }
  else
  {
    Serial.println("- write failed");
    write_file_status = WRITE_FILE_FAILED;
  }
  file.close();
 
return write_file_status; 

}

void appendFile(fs::FS &fs, const char *path, String message)
{
  Serial.printf("Appending to file: %s\r\n", path);

  File file = fs.open(path, FILE_APPEND);
  if (!file)
  {
    Serial.println("- failed to open file for appending");
    return;
  }
  if (file.print(message))
  {
    Serial.println("- message appended");
  }
  else
  {
    Serial.println("- append failed");
  }
  file.close();
}

int send_file_to_k210(fs::FS &fs, const char *path)
{
  Serial.printf("Reading file: %s\n", path);

  File file = fs.open(path);
  if (!file)
  {
    Serial.println("Failed to open file for reading");
    return FAILED_FILE_PATH;
  }

  Serial.print("Star Read from file ");
  vector<String> v;
  while (file.available())
  {
    boot_py += (char)file.read();
    v.push_back(file.readStringUntil('\n')); 
  }
  Serial.print("End Read from file: ");

  for (String s : v) {
    Serial.println(s);
  }

  if (v == vecOfstr)
  {
      file.close();
      return FILE_COMPARE;
  }

  if (v != vecOfstr)
  {
      file.close();
      return FAILED_FILE_COMPARE;
  }

}



void test_write_txt_file()
{
  const char* path= "/hello.txt";
  const char* message = "Hello";
 
  
  int expected =  writeFile(SD, path, message);
  int actual_read = send_file_to_k210(SD, path);

  TEST_ASSERT_EQUAL_INT  (expected, actual_read);

}

// void test_write_txt_file()
// {
//   const char* path= "/hello.txt";
//   const char* message = "Hello";
 
  
//   FS_WRITE_STATUS expected =  writeFile(SD, path, message);
//   FS_READ_STATUS actual_read, actual_string = send_file_to_k210(SD, path);

//   TEST_ASSERT_EQUAL (expected, actual_read);

// }

// void test_read_txt_file()
// {
//   const char* path= "/hello.txt";
//   const char* message = "Hello";
 
  
//   FS_WRITE_STATUS expected =  writeFile(SD, path, message);
//   FS_READ_STATUS actual_string = send_file_to_k210(SD, path);


//   TEST_ASSERT_EQUAL (3, actual_string);
// }


// void test_delete_file()
// {

//   FS_DELETE_STATUS expected = deleteFile(SD, "/hello.txt");
//   FS_READ_STATUS actual = send_file_to_k210(SD, "/hello.txt");

//   TEST_ASSERT_EQUAL_UINT8 (expected, actual);
// }


// void test_append_value()
// {
//   writeFile(SD, "/new_file.txt", "Llama");
//   appendFile(SD, "/new_file.txt", "Jumpwatts");
//   send_file_to_k210(SD, "/new_file.txt"); 
  
//   TEST_ASSERT_EQUAL_STRING (expected, actual);
// }

void test_sd_card_write_read_string()
{  
  const char* path= "/test_file_1.txt";
  const char* message = "Hello llama test file";

  writeFile(SD, path, message);
  send_file_to_k210(SD, path);
  const char* expected = message;
  const char* actual = boot_py.c_str ();
  TEST_ASSERT_EQUAL_STRING (expected, actual);
}

void setUp(void)
{
    initSDCard();
}

void tearDown(void)
{

}

void setup ()
{

    UNITY_BEGIN();
    // RUN_TEST(test_write_txt_file);
    RUN_TEST(test_sd_card_write_read_string);
    // RUN_TEST(test_delete_file);
    // RUN_TEST(test_append_value);
    // RUN_TEST(test_write_txt_file);
 
    UNITY_END();
}

void loop(){}